﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MFIP_1119
{
    /// <summary>
    /// Тип шаблона для сравнения: строковый или шестнадцатеричный.
    /// </summary>
    public enum PatternType
    {
        String,
        Hex
    }
}
